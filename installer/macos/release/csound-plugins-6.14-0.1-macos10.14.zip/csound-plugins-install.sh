
#!/bin/bash

####################################################
#                                                  #
#                  Csound Plugins                  #
#                                                  #
####################################################

# This is the installer script for Csound Plugins 0.1
# Csound Version: 6.14
# Created with macOS 10.14

# check that csound is installed
if [ -z "$(which csound)" ]; then
    echo "Csound does not seem to be installed. Exiting"
    exit -1
fi

# find installation
if [ -d /Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64 ]; then
    DEST=/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64
    SUDO=sudo
elif [ -d /home/em/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64 ]; then
    DEST=/home/em/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64
    SUDO=""
else
    echo "Did not find Opcodes64 folder. Exiting"
    exit -1
fi

echo "Found Opcodes64 in $DEST"

## set -x

$SUDO cp *.dylib $DEST

# test if files are there
for f in *.dylib; do
    fullpath=$DEST/$f
    if [ ! -e $fullpath ]; then
       echo "Installation failed, file not found: $fullpath"
       exit -1
    fi
done

echo "Installation OK!"

