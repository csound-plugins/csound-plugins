
# Csound Plugins (macos)

## Installation

Inside a terminal, run the script csound-plugins-install.sh. It will ask for
administrator rights

    $ ./csound-plugins-install.sh

This will put the plugins inside your Opcodes64 folder, depending on your
installation (/Library/... if installed via the official csound installer, or
~/Library/... if installed from source)

To uninstall the plugins, also inside a terminal:

    $ ./csound-plugins-uninstall.sh

## Manual installation

Copy all .dylib files to
/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64 if
you installed csound via the installer, or to
~/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64 if
csound was installed from source.

