#!/bin/bash

# check that csound is installed
if [ -z "$(which csound)" ]; then
    echo "Csound does not seem to be installed. Exiting"
    exit -1
fi

# find installation
if [ -d /Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64 ]; then
    DEST=/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64
elif [ -d /home/em/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64 ]; then
    DEST=/home/em/Library/Frameworks/CsoundLib64.framework/Versions/6.0/Resources/Opcodes64
else
    echo "Did not find Opcodes64 folder. Exiting"
    exit -1
fi

echo "Found Opcodes64 in $DEST"

for f in libelse.dylib libjsfx.dylib libklib.dylib libpoly.dylib ; do
    sudo rm -i "$DEST/$f"
done

